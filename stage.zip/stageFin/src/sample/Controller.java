package sample;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.control.Label;

import java.util.Vector;

public class Controller {
    Reseau reseau;

    //Les différentes parties de l'interface graphique
    @FXML
    Group accueil, infoA, infoB, infoH, infoRoutage, graphe, boutonMiM, boutonDH, dessinGraphe;


    //Les informations écrites en dur sur l'interface graphique
    @FXML
    Label aA, gA, pA, nbPersoA, nbPartnerA, keyA;
    @FXML
    Label aB, gB, pB, nbPersoB, nbPartnerB, keyB;
    @FXML
    Label aH, gH, pH, nbPersoH, nbPartner1, nbPartner2, keyH, keyH2;
    @FXML
    Label r1, r2, r3, r4, r5, r6, total;


    public void protocoleDH(ActionEvent actionEvent) {
        accueil.setVisible(false);
        boutonDH.setVisible(true);
        infoA.setVisible(true);
        infoB.setVisible(true);
        infoRoutage.setVisible(true);
        graphe.setVisible(true);
    }

    public void lancementDH(ActionEvent actionEvent) {
        int nbMachines = 13;
        reseau = new Reseau(nbMachines);
        reseau.diffieHellman();
        Machine mA = reseau.retourMachine(0);
        Machine mB = reseau.retourMachine(12);
        int ipA = mA.getIp();
        int ipB = mB.getIp();
        mA.creation3Value();
        mA.calculNbPerso();
        mB.creation1Value();
        //envoie du A
        double nbPerso = mA.getNbPerso();
        Message smsA = new Message(ipA, ipB, "nbPartner", nbPerso);
        smsA = reseau.routing(smsA);
        mA.creationMessage(smsA);
        valeurRoutage(smsA);
        dessinGraphe.setVisible(true);
        reseau.procedureMessage(mA);
        // envoie du p commun
        double p = mA.getP();
        Message smsP = new Message(ipA, ipB, "p", p);
        smsP = reseau.routing(smsP);
        mA.creationMessage(smsP);
        reseau.procedureMessage(mA);
        //envoie du g commun
        double g = mA.getG();
        Message smsG = new Message(ipA, ipB, "g", g);
        smsG = reseau.routing(smsG);
        mA.creationMessage(smsG);
        reseau.procedureMessage(mA);
        // envoie du nombre partenaire
        mB.calculNbPerso();
        double nbPart = mB.getNbPerso();
        Message smsPart = new Message(ipB, ipA, "nbPartner", nbPart);
        smsPart = reseau.routing(smsPart);
        mB.creationMessage(smsPart);
        reseau.procedureMessage(mB);
        //calcul clé
        mA.calculClee();
        mB.calculClee();

        aA.setText(String.valueOf(mA.getA()));
        gA.setText(String.valueOf(mA.getG()));
        pA.setText(String.valueOf(mA.getP()));
        nbPersoA.setText(String.valueOf(mA.getNbPerso()));
        nbPartnerA.setText(String.valueOf(mA.getPart()));
        keyA.setText(String.valueOf(mA.getKey()));

        aB.setText(String.valueOf(mB.getA()));
        gB.setText(String.valueOf(mB.getG()));
        pB.setText(String.valueOf(mB.getP()));
        nbPersoB.setText(String.valueOf(mB.getNbPerso()));
        nbPartnerB.setText(String.valueOf(mB.getPart()));
        keyB.setText(String.valueOf(mB.getKey()));
    }

    public void revenirAccueil(ActionEvent actionEvent) {
        accueil.setVisible(true);
        boutonMiM.setVisible(false);
        infoA.setVisible(false);
        infoB.setVisible(false);
        infoRoutage.setVisible(false);
        infoH.setVisible(false);
        graphe.setVisible(false);
        boutonDH.setVisible(false);
        dessinGraphe.setVisible(false);
    }

    public void attaqueMiM(ActionEvent actionEvent) {
        accueil.setVisible(false);
        boutonMiM.setVisible(true);
        infoA.setVisible(true);
        infoB.setVisible(true);
        infoH.setVisible(true);
        graphe.setVisible(true);
    }

    public void valeurRoutage(Message s) {
        Vector<Integer> route = s.getRoute();
        int tot = 0;
        r1.setText(String.valueOf(route.elementAt(0)));
        r2.setText(String.valueOf(route.elementAt(1)));
        r3.setText(String.valueOf(route.elementAt(2)));
        r4.setText(String.valueOf(route.elementAt(3)));
        r5.setText(String.valueOf(route.elementAt(4)));
        r6.setText(String.valueOf(route.elementAt(5)));
        for(int i : route)
            tot=tot+i;
        total.setText(String.valueOf(tot));
    }


    public void lancementMiM() {
        int nbMachines = 13;
        reseau = new Reseau(nbMachines);
        reseau.constructionReseau();
        //procédure echange
        Machine mA = reseau.retourMachine(0);
        Machine mB = reseau.retourMachine(12);
        Machine mH = reseau.retourMachine(4);
        int ipA = mA.getIp();
        int ipB = mB.getIp();
        mA.creation3Value();
        mA.calculNbPerso();
        mB.creation1Value();
        mH.creation1Value();
        // envoie du p commun
        double p = mA.getP();
        Message smsP = new Message(ipA, ipB, "p", p);
        smsP = reseau.routing(smsP);
        dessinGraphe.setVisible(true);
        mA.creationMessage(smsP);
        reseau.procedureMessageMiM(mA);
        //envoie du g commun
        double g = mA.getG();
        Message smsG = new Message(ipA, ipB, "g", g);
        smsG = reseau.routing(smsG);
        mA.creationMessage(smsG);
        reseau.procedureMessageMiM(mA);
        //calcul du A' de H
        mH.calculNbPerso();
        //envoie du A
        double nbPerso = mA.getNbPerso();
        Message smsA = new Message(ipA, ipB, "nbPartner", nbPerso);
        smsA = reseau.routing(smsA);
        mA.creationMessage(smsA);
        reseau.procedureMessageMiM(mA);
        // envoie du nombre partenaire
        mB.calculNbPerso();
        double nbPart = mB.getNbPerso();
        Message smsPart = new Message(ipB, ipA, "nbPartner", nbPart);
        smsPart = reseau.routing(smsPart);
        mB.creationMessage(smsPart);
        reseau.procedureMessageMiM(mB);
        //calcul clé
        mA.calculClee();
        mB.calculClee();
        mH.calculClee();
        mH.calculKey2();
        //affichage clé
        aA.setText(String.valueOf(mA.getA()));
        gA.setText(String.valueOf(mA.getG()));
        pA.setText(String.valueOf(mA.getP()));
        nbPersoA.setText(String.valueOf(mA.getNbPerso()));
        nbPartnerA.setText(String.valueOf(mA.getPart()));
        keyA.setText(String.valueOf(mA.getKey()));

        aB.setText(String.valueOf(mB.getA()));
        gB.setText(String.valueOf(mB.getG()));
        pB.setText(String.valueOf(mB.getP()));
        nbPersoB.setText(String.valueOf(mB.getNbPerso()));
        nbPartnerB.setText(String.valueOf(mB.getPart()));
        keyB.setText(String.valueOf(mB.getKey()));

        aH.setText(String.valueOf(mH.getA()));
        gH.setText(String.valueOf(mH.getG()));
        pH.setText(String.valueOf(mH.getP()));
        nbPersoH.setText(String.valueOf(mH.getNbPerso()));
        nbPartner1.setText(String.valueOf(mH.getPart()));
        nbPartner2.setText(String.valueOf(mH.getPart2()));
        keyH.setText(String.valueOf(mH.getKey()));
        keyH2.setText(String.valueOf(mH.getKey2()));
    }
}