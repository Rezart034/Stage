package sample;

public class PairInt {
    private int temps;
    private int ip;
    public PairInt(int temps, int ip){
        this.temps=temps;
        this.ip=ip;
    }
    public int getIp(){
        return this.ip;
    }
    public int getTemps(){
        return this.temps;
    }
    public void set(int temps,int ip){
        this.temps=temps;
        this.ip=ip;
    }
    public void set(PairInt p){
        this.temps=p.getTemps();
        this.ip=p.getIp();
    }
}
