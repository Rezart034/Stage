package sample;

import java.util.Vector;

public class Message {
    private final int ipEmetteur;
    private final int ipReceveur;
    private Vector<Integer> ipRoute;
    private final String type;
    private double content;

    public Message(int e, int r, String t, double c) {
        this.ipEmetteur = e;
        this.ipReceveur = r;
        this.type = t;
        this.content = c;
    }

    public Message(Message m) {
        this.ipEmetteur = m.emetteur();
        this.ipReceveur = m.receveur();
        this.ipRoute = new Vector<>(m.getRoute());
        this.type = m.lireType();
        this.content = m.lireContent();
    }

    public void setRoute(Vector<Integer> route) {
        this.ipRoute = new Vector<>(route);
    }

    public String lireType() {
        return this.type;
    }

    public double lireContent() {
        return this.content;
    }

    public void modifierMessage(double cont) {
        this.content = cont;
    }

    public Vector<Integer> getRoute() {
        return this.ipRoute;
    }

    public int dest() {
        return ipRoute.elementAt(0);
    }

    public void avanceRoute() {
        ipRoute.remove(0);
    }

    public int emetteur() {
        return ipEmetteur;
    }

    public int receveur() {
        return this.ipReceveur;
    }
}
