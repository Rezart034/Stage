package sample;

import java.util.Vector;

public class Machine {
    protected final int ip;    // num ip de la machine
    protected Vector<Message> pileReception;
    protected Vector<Message> pileEmition;
    protected double a;
    protected double p;
    protected double g;
    protected double nbPerso;
    protected double nbPartner;
    private double nbPartner2;
    protected double key;// clée de sécurité commune
    private double key2;

    public Machine(int num) {
        this.ip = num;
        this.a = 0;
        this.p = 0;
        this.g = 0;
        pileReception = new Vector<>();
        pileEmition = new Vector<>();

    }


    public int getIp() {    // retourne l'ip
        return ip;
    }

    public boolean emptyEmition() {
        return this.pileEmition.size() == 0;
    }

    public double getKey() {  // retourne la clée
        return key;
    }

    public void creation3Value() {
        this.a = (int) (Math.random() * 10 + 1);
        this.p = 53;
        this.g = (int) (Math.random() * (p - 2) + 1);
    }

    public void creation1Value() {
        this.a = (int) (Math.random() * 10 + 1);
    }

    public double getA() {
        return this.a;
    }

    public double getP() {
        return this.p;
    }

    public double getG() {
        return this.g;
    }

    public double getNbPerso() {
        return this.nbPerso;
    }

    public double getPart() {
        return nbPartner;
    }

    public double getPart2() {
        return nbPartner2;
    }

    public void calculKey2() {
        this.key2 = Math.pow(this.nbPartner2, a) % p;
    }

    public double getKey2() {
        return this.key2;
    }

    public void calculNbPerso() {
        this.nbPerso = Math.pow(this.g, this.a) % this.p;
    }

    public void lectureMessage() {
        Message m = this.pileReception.elementAt(0);
        if (m.receveur() != this.ip) {
            m.avanceRoute();
            this.pileEmition.add(m);
        } else {
            switch (m.lireType()) {
                case "p":
                    this.p = m.lireContent();
                    break;
                case "g":
                    this.g = m.lireContent();
                    break;
                case "nbPartner":
                    this.nbPartner = m.lireContent();
                    break;
            }
        }
        this.pileReception.remove(0);
    }

    public void lectureMessageMiM() {
        Message m = this.pileReception.elementAt(0);
        if (this.getIp() == 4) {
            switch (m.lireType()) {
                case "p":
                    this.p = m.lireContent();
                    break;
                case "g":
                    this.g = m.lireContent();
                    break;
                case "nbPartner":
                    if (m.emetteur() == 0) {
                        this.nbPartner = m.lireContent();
                    } else {
                        this.nbPartner2 = m.lireContent();
                    }
                    m.modifierMessage(nbPerso);
                    break;
            }
        }
        if (m.receveur() != this.ip) {
            m.avanceRoute();
            this.pileEmition.add(m);
        } else {
            switch (m.lireType()) {
                case "p":
                    this.p = m.lireContent();
                    break;
                case "g":
                    this.g = m.lireContent();
                    break;
                case "nbPartner":
                    this.nbPartner = m.lireContent();
                    break;
            }
        }
        this.pileReception.remove(0);
    }

    public void calculClee() {
        this.key = Math.pow(nbPartner, a) % p;
    }

    public Message sendMessage() {
        Message m = new Message(this.pileEmition.elementAt(0));
        this.pileEmition.remove(0);
        return m;
    }

    public void receptionMessage(Message m) {
        this.pileReception.add(m);
    }

    public void creationMessage(Message m) {
        pileEmition.add(m);
    }
}
