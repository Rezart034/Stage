package sample;

import java.util.Collections;
import java.util.Vector;

public class Reseau {
    Vector<Machine> reseau;
    private final int nbMachines;
    int[][] matriceAdjacence;

    public Reseau(int nbMachines) {
        int i, j;
        matriceAdjacence = new int[nbMachines][nbMachines];
        for (i = 0; i < nbMachines; i++) {
            for (j = 0; j < nbMachines; j++) {
                matriceAdjacence[i][j] = 0;
            }
        }
        reseau = new Vector<>();
        this.nbMachines = nbMachines;

    }

    public void associationMachine(int ip1, int ip2, int poids) {
        matriceAdjacence[ip1][ip2] = poids;
        matriceAdjacence[ip2][ip1] = poids;
    }

    public Machine getMachineToIP(int num) {
        for (Machine m : reseau) {
            if (m.getIp() == num)
                return m;
        }
        return null;
    }

    public void procedureMessage(Machine mA) {
        Machine m = mA;
        Message sms;
        while (!m.emptyEmition()) {
            sms = new Message(m.sendMessage());
            m = getMachineToIP(sms.dest());
            m.receptionMessage(sms);
            m.lectureMessage();
        }
    }

    public void procedureMessageMiM(Machine mA) {
        Machine m = mA;
        Message sms;
        while (!m.emptyEmition()) {
            sms = new Message(m.sendMessage());
            m = getMachineToIP(sms.dest());
            m.receptionMessage(sms);
            m.lectureMessageMiM();
        }
    }

    public void constructionReseau() {
        Machine a = new Machine(0);
        Machine b = new Machine(1);
        Machine c = new Machine(2);
        Machine d = new Machine(3);
        Machine e = new Machine(4);
        Machine f = new Machine(5);
        Machine g = new Machine(6);
        Machine h = new Machine(7);
        Machine i = new Machine(8);
        Machine j = new Machine(9);
        Machine k = new Machine(10);
        Machine l = new Machine(11);
        Machine m = new Machine(12);
        reseau.add(a);
        reseau.add(b);
        reseau.add(c);
        reseau.add(d);
        reseau.add(e);
        reseau.add(f);
        reseau.add(g);
        reseau.add(h);
        reseau.add(i);
        reseau.add(j);
        reseau.add(k);
        reseau.add(l);
        reseau.add(m);
        associationMachine(0, 1, 5);
        associationMachine(0, 2, 15);
        associationMachine(1, 3, 25);
        associationMachine(1, 4, 10);
        associationMachine(2, 5, 5);
        associationMachine(3, 6, 5);
        associationMachine(4, 5, 25);
        associationMachine(4, 8, 30);
        associationMachine(4, 9, 5);
        associationMachine(5, 7, 15);
        associationMachine(6, 8, 20);
        associationMachine(7, 10, 10);
        associationMachine(8, 12, 20);
        associationMachine(9, 11, 20);
        associationMachine(10, 11, 10);
        associationMachine(11, 12, 15);
    }

    public boolean sontVoisins(int ip1, int ip2) {
        return matriceAdjacence[ip1][ip2] > 0;
    }

    public int poidsArrete(int ip1, int ip2) {
        return matriceAdjacence[ip1][ip2];
    }

    public Message routing(Message m) {
        int ipA = m.emetteur();
        int ipB = m.receveur();
        Vector<Integer> route = new Vector<>();
        PairInt curseur = new PairInt(0, ipA);
        PairInt[] avancement = new PairInt[nbMachines];
        PairInt[] fin = new PairInt[nbMachines];
        int i;
        int j = 0;
        int ipMin = ipA;
        PairInt min = new PairInt(Integer.MAX_VALUE, -1);
        for (i = 0; i < nbMachines; i++) {
            if (i == ipA) {
                avancement[i] = null;
                fin[i] = new PairInt(0, ipA);
            } else
                avancement[i] = new PairInt(Integer.MAX_VALUE, -1);
        }
        while ((curseur.getIp() != ipB) && (j <= nbMachines)) {
            i = 0;
            min.set(Integer.MAX_VALUE, -1);
            for (PairInt p : avancement) {
                if (p != null) {
                    if (sontVoisins(curseur.getIp(), i) && p.getTemps() > (curseur.getTemps() + poidsArrete(i, curseur.getIp()))) {
                        p.set(poidsArrete(i, curseur.getIp()) + curseur.getTemps(), curseur.getIp());
                    }
                    if (p.getTemps() < min.getTemps()) {
                        min.set(p.getTemps(), i);
                        ipMin = p.getIp();
                    }
                }
                i++;
            }
            fin[min.getIp()] = new PairInt(min.getTemps(), ipMin);
            curseur.set(min);
            avancement[min.getIp()] = null;
            j++;
        }
        int ipSuite = ipB;
        route.add(ipB);
        while (ipSuite != ipA) {
            ipSuite = fin[ipSuite].getIp();
            route.add(ipSuite);
        }
        Collections.reverse(route);
        m.setRoute(route);
        return m;
    }

    public void diffieHellman() {
        constructionReseau();
        //procédure échange
        Machine mA = reseau.elementAt(0);
        Machine mB = reseau.elementAt(12);
        int ipA = mA.getIp();
        int ipB = mB.getIp();
        mA.creation3Value();
        mA.calculNbPerso();
        mB.creation1Value();
        //envoie du A
        double nbPerso = mA.getNbPerso();
        Message smsA = new Message(ipA, ipB, "nbPartner", nbPerso);
        smsA = routing(smsA);
        mA.creationMessage(smsA);
        procedureMessage(mA);
        // envoie du p commun
        double p = mA.getP();
        Message smsP = new Message(ipA, ipB, "p", p);
        smsP = routing(smsP);
        mA.creationMessage(smsP);
        procedureMessage(mA);
        //envoie du g commun
        double g = mA.getG();
        Message smsG = new Message(ipA, ipB, "g", g);
        smsG = routing(smsG);
        mA.creationMessage(smsG);
        procedureMessage(mA);
        // envoie du nombre partenaire
        mB.calculNbPerso();
        double nbPart = mB.getNbPerso();
        Message smsPart = new Message(ipB, ipA, "nbPartner", nbPart);
        smsPart = routing(smsPart);
        mB.creationMessage(smsPart);
        procedureMessage(mB);
        //calcul clé
        mA.calculClee();
        mB.calculClee();
        //affichage clé
        System.out.println("Hote A :");
        System.out.println("a = " + mA.getA());
        System.out.println("p = " + mA.getP());
        System.out.println("g = " + mA.getG());
        System.out.println("A = " + mA.getNbPerso());
        System.out.println("B = " + mA.getPart());
        System.out.println("Clé : " + mA.getKey());
        System.out.println("Hote B :");
        System.out.println("b = " + mB.getA());
        System.out.println("p = " + mB.getP());
        System.out.println("g = " + mB.getG());
        System.out.println("B = " + mB.getNbPerso());
        System.out.println("A : " + mB.getPart());
        System.out.println("Clé : " + mB.getKey());
    }

    public Machine retourMachine(int index) {
        return reseau.elementAt(index);
    }

    public void manInThMiddle() {
        constructionReseau();
        //procédure echange
        Machine mA = reseau.elementAt(0);
        Machine mB = reseau.elementAt(12);
        Machine mH = reseau.elementAt(4);
        int ipA = mA.getIp();
        int ipB = mB.getIp();
        mA.creation3Value();
        mA.calculNbPerso();
        mB.creation1Value();
        mH.creation1Value();
        // envoie du p commun
        double p = mA.getP();
        Message smsP = new Message(ipA, ipB, "p", p);
        smsP = routing(smsP);
        mA.creationMessage(smsP);
        procedureMessageMiM(mA);
        //envoie du g commun
        double g = mA.getG();
        Message smsG = new Message(ipA, ipB, "g", g);
        smsG = routing(smsG);
        mA.creationMessage(smsG);
        procedureMessageMiM(mA);
        //calcul du A' de H
        mH.calculNbPerso();
        //envoie du A
        double nbPerso = mA.getNbPerso();
        Message smsA = new Message(ipA, ipB, "nbPartner", nbPerso);
        smsA = routing(smsA);
        mA.creationMessage(smsA);
        procedureMessageMiM(mA);
        // envoie du nombre partenaire
        mB.calculNbPerso();
        double nbPart = mB.getNbPerso();
        Message smsPart = new Message(ipB, ipA, "nbPartner", nbPart);
        smsPart = routing(smsPart);
        mB.creationMessage(smsPart);
        procedureMessageMiM(mB);
        //calcul clé
        mA.calculClee();
        mB.calculClee();
        mH.calculClee();
        mH.calculKey2();
        //affichage clé
        System.out.println("Hote A :");
        System.out.println("a = " + mA.getA());
        System.out.println("p = " + mA.getP());
        System.out.println("g = " + mA.getG());
        System.out.println("A = " + mA.getNbPerso());
        System.out.println("Clé : " + mA.getKey());
        System.out.println("H : " + mA.getPart());
        System.out.println("Hote H :");
        System.out.println("h = " + mH.getA());
        System.out.println("p = " + mH.getP());
        System.out.println("g = " + mH.getG());
        System.out.println("H = " + mH.getNbPerso());
        System.out.println("A : " + mH.getPart());
        System.out.println("B : " + mH.getPart2());
        System.out.println("Clé commune avec A: " + mH.getKey());
        System.out.println("Clé commune avec B: " + mH.getKey2());
        System.out.println("Hote B :");
        System.out.println("b = " + mB.getA());
        System.out.println("p = " + mB.getP());
        System.out.println("g = " + mB.getG());
        System.out.println("B = " + mB.getNbPerso());
        System.out.println("H : " + mB.getPart());
        System.out.println("Clé : " + mB.getKey());
    }
}
